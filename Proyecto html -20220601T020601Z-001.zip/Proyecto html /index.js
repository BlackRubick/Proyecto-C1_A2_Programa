const auxcomentario = [{impri: " "}]

localStorage.setItem("auxComentario",JSON.stringify(auxcomentario))